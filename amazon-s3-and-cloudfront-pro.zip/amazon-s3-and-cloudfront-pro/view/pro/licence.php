<div id="tab-licence" data-prefix="as3cf" class="as3cf-tab as3cf-content">
	<div class="as3cf-licence">
		<?php do_action( 'as3cf_licence_field' ) ?>
	</div>
</div>

