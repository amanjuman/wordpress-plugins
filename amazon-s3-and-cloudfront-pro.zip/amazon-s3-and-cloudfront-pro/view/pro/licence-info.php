<section class="as3cf-licence-info support support-section">
	<h3 class="as3cf-section-heading"><?php _e( 'NULLED, NO SUPPORT', 'amazon-s3-and-cloudfront' ); ?></h3>
</section>