<div class="wrap as3cf-main" data-view="<?php echo $page; ?>">

	<h1><?php echo esc_html( $page_title ); ?></h1>