<?php

namespace DeliciousBrains\WP_Offload_Media\Upgrades\Exceptions;

class Too_Many_Errors_Exception extends \Exception {

}