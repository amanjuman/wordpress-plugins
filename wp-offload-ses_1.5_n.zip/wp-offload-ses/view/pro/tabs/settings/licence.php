<div id="tab-licence" data-prefix="wposes" class="wposes-tab wposes-content">
	<?php do_action( 'wposes_licence_field' ); ?>
</div>
