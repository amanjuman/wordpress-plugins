<div class="wrap wposes-main <?php echo $this->is_pro() ? 'wposes-pro' : 'wposes-lite'; ?>" data-view="<?php echo $page; ?>">

	<h1><?php echo esc_html( $page_title ); ?></h1>