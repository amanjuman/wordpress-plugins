<?php

namespace DeliciousBrains\WP_Offload_Media_Assets_Pull\Exceptions;

class Invalid_Response_Code_Exception extends Domain_Check_Exception {

}