<?php

namespace DeliciousBrains\WP_Offload_Media_Assets_Pull\Exceptions;

class Ssl_Connection_Exception extends Domain_Check_Exception {

}