<?php

namespace DeliciousBrains\WP_Offload_Media_Assets_Pull\Exceptions;

class S3_Bucket_Origin_Exception extends Domain_Check_Exception {

}
