<?php

namespace DeliciousBrains\WP_Offload_Media_Assets_Pull\Exceptions;

class Unresolveable_Hostname_Exception extends Domain_Check_Exception {

}