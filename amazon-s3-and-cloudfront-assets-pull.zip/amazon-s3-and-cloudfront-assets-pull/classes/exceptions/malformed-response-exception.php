<?php

namespace DeliciousBrains\WP_Offload_Media_Assets_Pull\Exceptions;

class Malformed_Response_Exception extends Domain_Check_Exception {

}